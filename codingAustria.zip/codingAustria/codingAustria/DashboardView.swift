//
//  DashboardView.swift
//  codingAustria
//
//  Created by David Pfluegl on 29.07.23.
//

import SwiftUI
import Foundation
import HealthKit

struct DashboardView: View {
    
    @EnvironmentObject var vm: HealthKitViewModel
    @State private var showDatePicker = false
    @State private var backgroundDate: Date? = nil
    @State private var foregroundDate: Date = Date()
    @State private var showSleepList = false
    
    @Environment(\.managedObjectContext) var moc
    @FetchRequest(sortDescriptors: [SortDescriptor(\.date, order: .reverse)]) var sleeps: FetchedResults<Sleep>
    
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    
    var sleepOnSelectedDate: [Sleep] {
        let calendar = Calendar.current
        return sleeps.filter { sleep in
            let sleepDate = sleep.date as Date?  // replace 'date' with your attribute name
            if let sleepDate = sleepDate {
                let startOfSelectedDay = calendar.startOfDay(for: vm.specificDate)
                let startOfNextDay = calendar.date(byAdding: .day, value: 1, to: startOfSelectedDay)
                
                return sleepDate >= startOfSelectedDay && sleepDate < startOfNextDay!
            }
            return false
        }
    }
    
    var sleepHours: Double {
        return sleepOnSelectedDate.reduce(0) { $0 + Double($1.hours) }
    }
    
    var sleepQuality: Double {
        return sleepOnSelectedDate.reduce(0) { $0 + Double($1.quality) }
    }

    var body: some View {
        if vm.isAuthorizedForActiveEnergy {
            VStack {
                VStack {
                    HStack {
                        Button(action: {
                            showDatePicker.toggle()
                            //                      showFoodPicker = false
                        }) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 24, style: .continuous)
                                    .foregroundColor(Color.init(uiColor: .systemGray6))
                                    .frame(width: nil, height: 60)
                                HStack {
                                    Image (systemName: "cross.fill")
                                        .foregroundColor(.red)
                                    if Calendar.current.isDate(vm.specificDate, inSameDayAs: Date()) {
                                        Text("Today")
                                            .font(.system(size: 20, weight: .bold, design: .rounded))
                                        
                                    } else {
                                        Text("\(vm.specificDate, formatter: dateFormatter)")
                                            .font(.system(size: 20, weight: .bold
                                                          , design: .rounded))
                                        
                                    }
                                    Spacer()
                                    if !showDatePicker {
                                        Image (systemName: "calendar")
                                            .foregroundColor(.accentColor)
                                            .font(.system(size: 24, weight: .regular, design: .rounded))
                                        
                                    }
                                    if showDatePicker {
                                        Button {
                                            showDatePicker = false
                                            vm.readActiveEnergyBurned(forDate: vm.specificDate)
                                        } label: {
                                            Text ("Done")
                                                .font(.system(size: 20, weight: .bold, design: .rounded))
                                        }
                                    }
                                }
                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                .foregroundColor(.black)
                                .padding(.horizontal)
                                .transaction { transaction in
                                    transaction.animation = nil
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                    
                    if showDatePicker {
                        if showDatePicker {
                            DatePicker("Date", selection: $vm.specificDate, in: ...Date(), displayedComponents: [.date])
                                .datePickerStyle(GraphicalDatePickerStyle())
                                .labelsHidden()
                                .onChange(of: vm.specificDate) { newValue in
                                    vm.readActiveEnergyBurned(forDate: newValue)
                                    showDatePicker = false
                                }
                        }
                    }
                }
                .padding(.horizontal)

                
                ScrollView {
                    VStack {
                        if sleepOnSelectedDate.count != 0 {
                            ZStack {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                                        .foregroundColor(.white)
                                    VStack {
                                        Text ("Sleep Score")
                                            .font(.system(size: 24, weight: .bold, design: .rounded))
                                            .padding(.bottom)
                                        
                                        HStack (alignment: .top){
                                            Text("Hours")
                                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                            Spacer()
                                            
                                            VStack (alignment: .trailing){
                                                HStack (spacing: 8){
                                                    Image (systemName: "hourglass")
                                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                                        .foregroundColor(sleepHours >= 6 ? Color.green : Color.gray)
                                                    Image (systemName: "hourglass")
                                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                                        .foregroundColor(sleepHours > 6 ? Color.green : Color.gray)
                                                    Image (systemName: "hourglass")
                                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                                        .foregroundColor(sleepHours == 8 ? Color.green : Color.gray)
                                                }
                                                .padding(.bottom, 6)

                                                Text("\(String(format: "%.0f", sleepHours)) hours")
                                                    .font(.system(size: 14, weight: .bold, design: .rounded))
                                                    .opacity(0.4)
                                            }
                                        }

                                        Divider()
                                            .padding()
                                        
                                        HStack (alignment: .top){
                                            Text("Quality")
                                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                            Spacer()

                                            VStack (alignment: .trailing){
                                                HStack (spacing: 12){
                                                    Image (systemName: "moon.stars.fill")
                                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                                        .foregroundColor(sleepQuality >= 2 ? Color.green : Color.gray)
                                                    Image (systemName: "moon.stars.fill")
                                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                                        .foregroundColor(sleepQuality >= 3 ? Color.green : Color.gray)
                                                    Image (systemName: "moon.stars.fill")
                                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                                        .foregroundColor(sleepQuality == 4 ? Color.green : Color.gray)
                                                }
                                                .padding(.bottom, 6)
                                                
                                                Text("\(sleepQualityText()) sleep quality")
                                                    .font(.system(size: 14, weight: .bold, design: .rounded))
                                                    .opacity(0.4)
                                            }
                                        }
                                        
                                        Button {
                                            showSleepList.toggle()
                                        } label: {
                                            Text ("View all")
                                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                        }
                                        .padding(.top, 24)
                                        .fullScreenCover(isPresented: $showSleepList) {
                                            SleepScoreListView()
                                        }
                                    }
                                    .padding(36)
                                }
                            }
                        } else {
                            AddSleepView()
                        }
                        ZStack {
                            RoundedRectangle(cornerRadius: 24, style: .continuous)
                                .foregroundColor(.white)
                            VStack {
                                Text ("Activity Score")
                                    .font(.system(size: 24, weight: .bold, design: .rounded))
                                    .padding()
                                
                                HStack (spacing: 12){
                                    Image (systemName: "figure.run")
                                        .font(.system(size: 48, weight: .bold, design: .rounded))
                                        .foregroundColor(vm.userActiveEnergy > 199 ? Color.green : Color.gray)
                                    Image (systemName: "figure.run")
                                        .font(.system(size: 48, weight: .bold, design: .rounded))
                                        .foregroundColor(vm.userActiveEnergy > 399 ? Color.green : Color.gray)
                                    Image (systemName: "figure.run")
                                        .font(.system(size: 48, weight: .bold, design: .rounded))
                                        .foregroundColor(vm.userActiveEnergy > 599 ? Color.green : Color.gray)
                                    
                                }
                                .padding()
                                
                                VStack {
                                    if (0..<200).contains(vm.userActiveEnergy) {
                                        VStack {
                                            ProgressView(value: vm.userActiveEnergy, total: 200)
                                                .animation(.easeOut, value: vm.userActiveEnergy)
                                                .tint(.red)
                                            Text("\(String(format: "%.0f", vm.userActiveEnergy)) / 200")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                        }
                                    }
                                    if (200..<400).contains(vm.userActiveEnergy) {
                                        VStack {
                                            ProgressView(value: vm.userActiveEnergy, total: 400)
                                                .animation(.easeOut, value: vm.userActiveEnergy)
                                                .tint(.red)
                                            Text("\(String(format: "%.0f", vm.userActiveEnergy)) / 400")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                        }
                                    }
                                    if (400..<600).contains(vm.userActiveEnergy) {
                                        VStack {
                                            ProgressView(value: vm.userActiveEnergy, total: 600)
                                                .animation(.easeOut, value: vm.userActiveEnergy)
                                                .tint(.red)
                                            Text("\(String(format: "%.0f", vm.userActiveEnergy)) / 600")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                        }
                                    }
                                    if vm.userActiveEnergy >= 600 {
                                        VStack {
                                            ProgressView(value: 600, total: 600)
                                                .animation(.easeOut, value: vm.userActiveEnergy)
                                                .tint(.red)
                                            Text("\(String(format: "%.0f", vm.userActiveEnergy)) / 600")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                        }
                                    }
                                    Text ("kcal")
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                        .opacity(0.4)
                                }
                                .padding()
                            }
                            .padding()
                        }
                    }
                    .padding(.horizontal)
                    
                    
                }
            }
            .background(Color.init(uiColor: .systemGray6))
            .onAppear {
                vm.readActiveEnergyBurned(forDate: vm.specificDate)
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)) { _ in
                self.backgroundDate = Date()
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
                self.foregroundDate = Date()
                
                if let backgroundDate = self.backgroundDate {
                    let timeSpentInBackground = self.foregroundDate.timeIntervalSince(backgroundDate)
                    
                    if timeSpentInBackground > 300 { // Change the date to today if app was in background for 5 minutes or more
                        self.vm.specificDate = Date()
                        self.vm.readActiveEnergyBurned(forDate: self.vm.specificDate)
                    }
                }
            }
            
        } else {
            VStack {
                Image ("Logo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 120)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                    .shadow(color: Color.black.opacity(0.12), radius: 6, x: 2, y: 2 )
                    .padding(.bottom, 36)
                    
                Text("Please Authorize HealthKit Access")
                    .font(.system(size: 36, weight: .bold, design: .rounded))
                    .padding(.horizontal, 24)
                    .padding(.vertical)
                    .multilineTextAlignment(.center)
                Button {
                    vm.healthRequest()
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .frame(width: nil, height: 60)
                            .foregroundColor(.red)
                        Text("Authorize HealthKit")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }
                }
            }
            .padding()
        }
    }
    
    func activeEnergy() -> Double {
        if vm.userActiveEnergy != 0.0 {
            return vm.userActiveEnergy / 400
        } else {
            return 0.0
        }
    }
    
    func activeEnergyRounded() -> Int {
        if vm.userActiveEnergy != 0.0 {
            let activeEnergy = Int(vm.userActiveEnergy / 400)
            return activeEnergy
        } else {
            return 0
        }
    }
    
    func activityProgress() -> Double {
        let progress = Double(activeEnergy()) - Double(activeEnergyRounded())
        return progress
    }
    
    func sleepQualityText() -> String {
        switch sleepQuality {
        case 1.0:
            return "Terrible"
        case 2.0:
            return "Bad"
        case 3.0:
            return "Good"
        case 4.0:
            return "Great"
            
        default:
            return "Ok"
        }
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
            .environmentObject(HealthKitViewModel())
    }
}
