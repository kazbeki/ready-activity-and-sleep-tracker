//
//  codingAustriaApp.swift
//  codingAustria
//
//  Created by David Pfluegl on 26.07.23.
//

import SwiftUI
import UIKit

@main
struct codingAustriaApp: App {
    
    @StateObject private var dataController = DataController()

    var healthVM = HealthKitViewModel()

    var body: some Scene {
        WindowGroup {
            DashboardView()
                .environmentObject(healthVM)
                .environment(\.managedObjectContext, dataController.container.viewContext)
        }
    }
}
