//
//  HealthKitViewModel.swift
//  codingAustria
//
//  Created by David Pfluegl on 26.07.23.
//

import SwiftUI
import Foundation
import HealthKit

class HealthKitViewModel: ObservableObject {
    
    private var healthStore = HKHealthStore()
    private var healthKitManager = HealthKitManager()
    @Published var userActiveEnergy = 0.0
    @Published var isAuthorized = false
    @Published var isAuthorizedForActiveEnergy = false
    @Published var specificDate = Date()
    
    init() {
        changeAuthorizationStatus()
    }
    
    func healthRequest() {
        healthKitManager.setUpHealthRequest(healthStore: healthStore) {
            self.changeAuthorizationStatus()
            self.readActiveEnergyBurned(forDate: self.specificDate)
        }
    }
    
    func readActiveEnergyBurned(forDate date: Date) {
        healthKitManager.readActiveEnergyCount(forDate: date, healthStore: healthStore) { activeEnergy in
            if activeEnergy != 0.0 {
                DispatchQueue.main.async {
                    self.userActiveEnergy = activeEnergy
                }
            }
        }
    }
    
    func changeAuthorizationStatus() {
        guard let activeEnergyType = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) else { return }
        let activeEnergyStatus = self.healthStore.authorizationStatus(for: activeEnergyType)

        DispatchQueue.main.async {
            switch activeEnergyStatus {
            case .notDetermined:
                self.isAuthorizedForActiveEnergy = false
            case .sharingDenied:
                self.isAuthorizedForActiveEnergy = false
            case .sharingAuthorized:
                self.isAuthorizedForActiveEnergy = true
            @unknown default:
                self.isAuthorizedForActiveEnergy = false
            }
        }
    }
}
