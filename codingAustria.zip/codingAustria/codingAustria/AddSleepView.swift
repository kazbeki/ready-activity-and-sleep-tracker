//
//  AddSleepView.swift
//  codingAustria
//
//  Created by David Pfluegl on 29.07.23.
//

import SwiftUI
import Combine
import CoreData

#if canImport(UIKit)
extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
#endif

struct AddSleepView: View {
    
    @EnvironmentObject var vm: HealthKitViewModel
    @Environment(\.managedObjectContext) var moc

    @State private var date = Date()
    @State private var hours: Double = 6.0
    @State private var quality: Double = 3.0
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .foregroundColor(.white)
            VStack {
                VStack {
                    
                    HStack {
                        Text ("How did you sleep?")
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                        Spacer()
                    }
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .foregroundColor(.white)
                        VStack (spacing: 24){
                            VStack {
                                HStack {
                                    Text ("Hours")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                    
                                    Spacer()
                                    
                                    Text ("\(String(format: "%.0f", hours))")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                                                        
                                    HStack (spacing: 4){
                                        Image (systemName: "hourglass")
                                            .font(.system(size: 18, weight: .bold, design: .rounded))
                                            .foregroundColor(hours >= 6 ? Color.green : Color.gray)
                                        Image (systemName: "hourglass")
                                            .font(.system(size: 18, weight: .bold, design: .rounded))
                                            .foregroundColor(hours > 6 ? Color.green : Color.gray)
                                        Image (systemName: "hourglass")
                                            .font(.system(size: 18, weight: .bold, design: .rounded))
                                            .foregroundColor(hours == 8 ? Color.green : Color.gray)
                                        
                                    }
                                    
//                                    if (0..<6).contains(hours){
//                                        Image ("neutralFace")
//                                            .resizable()
//                                            .aspectRatio(contentMode: .fit)
//                                            .frame(width: 24)
//                                    }
//                                    if (6..<8).contains(hours){
//                                        Image ("happyFace")
//                                            .resizable()
//                                            .aspectRatio(contentMode: .fit)
//                                            .frame(width: 24)
//                                    }
//                                    if hours == 8 {
//                                        Image ("starFace")
//                                            .resizable()
//                                            .aspectRatio(contentMode: .fit)
//                                            .frame(width: 24)
//                                    }
                                }
                                
                                Slider(value: $hours, in: 0.0...8.0, step: 1)
                                    .tint(hours < 6 ? Color.red : Color.green)
                                    .onTapGesture {
                                        hideKeyboard()
                                    }
                                
                                HStack (alignment: .top){
                                    Text ("0")
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                        .opacity(0.4)
                                    Spacer()
                                    Text ("8+")
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                        .opacity(0.4)
                                }
                            }
                            VStack {
                                HStack {
                                    Text ("Quality")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                    
                                    Spacer()
                                    
                                    Text ("\(sleepQuality())")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                    
                                    HStack (spacing: 4){
                                        Image (systemName: "moon.stars.fill")
                                            .font(.system(size: 18, weight: .bold, design: .rounded))
                                            .foregroundColor(quality >= 2 ? Color.green : Color.gray)
                                        Image (systemName: "moon.stars.fill")
                                            .font(.system(size: 18, weight: .bold, design: .rounded))
                                            .foregroundColor(quality >= 3 ? Color.green : Color.gray)
                                        Image (systemName: "moon.stars.fill")
                                            .font(.system(size: 18, weight: .bold, design: .rounded))
                                            .foregroundColor(quality == 4 ? Color.green : Color.gray)
                                        
                                    }
                                }
                                
                                Slider(value: $quality, in: 1.0...4.0, step: 1)
                                    .tint(quality < 2 ? Color.red : Color.green)
                                    .onTapGesture {
                                        hideKeyboard()
                                    }
                                
                                HStack (alignment: .top){
                                    Text ("bad")
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                        .opacity(0.4)
                                    Spacer()
                                    Text ("great")
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                        .opacity(0.4)
                                }
                            }
                    }
                        .padding()
                }
            }
                Button {
                    let newSleep = Sleep(context: moc)
                    newSleep.id = UUID()
                    newSleep.date = vm.specificDate
                    newSleep.hours = hours
                    newSleep.quality = quality
                    
                    try? moc.save()
                    
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .frame(width: nil, height: 60)
                            .foregroundColor(.green)
                        Text ("Save")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }

                }
            }
            .padding()
        }
    }
    
    func sleepQuality() -> String {
        switch quality {
        case 1.0:
            return "Terrible"
        case 2.0:
            return "Bad"
        case 3.0:
            return "Good"
        case 4.0:
            return "Great"
            
        default:
            return "Ok"
        }
    }
}

struct AddSleepView_Previews: PreviewProvider {
    static var previews: some View {
        AddSleepView()
            .environmentObject(HealthKitViewModel())
    }
}
