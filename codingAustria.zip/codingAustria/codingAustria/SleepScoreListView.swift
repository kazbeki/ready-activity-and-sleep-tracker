//
//  SleepScoreListView.swift
//  codingAustria
//
//  Created by David Pfluegl on 29.07.23.
//

import SwiftUI
import Foundation
import HealthKit

struct SleepScoreListView: View {
    
    @EnvironmentObject var vm: HealthKitViewModel
    @State private var showDatePicker = false
    @State private var backgroundDate: Date? = nil
    @State private var foregroundDate: Date = Date()
    
    @Environment(\.dismiss) private var dismiss
    
    @Environment(\.managedObjectContext) var moc
    @FetchRequest(sortDescriptors: [SortDescriptor(\.date, order: .reverse)]) var sleeps: FetchedResults<Sleep>
    
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    
    var sleepOnSelectedDate: [Sleep] {
        let calendar = Calendar.current
        return sleeps.filter { sleep in
            let sleepDate = sleep.date as Date?  // replace 'date' with your attribute name
            if let sleepDate = sleepDate {
                let startOfSelectedDay = calendar.startOfDay(for: vm.specificDate)
                let startOfNextDay = calendar.date(byAdding: .day, value: 1, to: startOfSelectedDay)
                
                return sleepDate >= startOfSelectedDay && sleepDate < startOfNextDay!
            }
            return false
        }
    }
    
    var sleepHours: Double {
        return sleepOnSelectedDate.reduce(0) { $0 + Double($1.hours) }
    }
    
    var sleepQuality: Double {
        return sleepOnSelectedDate.reduce(0) { $0 + Double($1.quality) }
    }
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                Button {
                    dismiss()
                } label: {
                    Image (systemName: "xmark")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .opacity(0.4)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal)
            .padding(.top)
            
            ScrollView {
                VStack {
                    HStack {
                        Text ("Sleep History")
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                        Spacer()
                    }
                    .padding()
                    
                    ForEach(sleeps) { sleep in
                        ZStack {
                            RoundedRectangle(cornerRadius: 24, style: .continuous)
                                .foregroundColor(.white)
                            VStack {
                                HStack {
                                    Text ("\(dateFormatter.string(from: sleep.date!))")
                                        .font(.system(size: 14, weight: .bold, design: .rounded))
                                        .foregroundColor(.gray)
                                }
                                HStack (alignment: .top){
                                    VStack (alignment: .leading){
                                        HStack (spacing: 8){
                                            Image (systemName: "hourglass")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                                .foregroundColor(sleep.hours >= 6 ? Color.green : Color.gray)
                                            Image (systemName: "hourglass")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                                .foregroundColor(sleep.hours > 6 ? Color.green : Color.gray)
                                            Image (systemName: "hourglass")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                                .foregroundColor(sleep.hours == 8 ? Color.green : Color.gray)
                                        }
                                        .padding(.bottom, 6)

                                        Text("\(String(format: "%.0f", sleep.hours)) hours")
                                            .font(.system(size: 13, weight: .bold, design: .rounded))
                                            .opacity(0.4)
                                    }
                                    
                                    Spacer()

                                    VStack (alignment: .trailing){
                                        HStack (spacing: 8){
                                            Image (systemName: "moon.stars.fill")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                                .foregroundColor(sleep.quality >= 2 ? Color.green : Color.gray)
                                            Image (systemName: "moon.stars.fill")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                                .foregroundColor(sleep.quality >= 3 ? Color.green : Color.gray)
                                            Image (systemName: "moon.stars.fill")
                                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                                .foregroundColor(sleep.quality == 4 ? Color.green : Color.gray)


                                        }
                                        .padding(.bottom, 6)

                                        if sleep.quality == 1.0 {
                                            Text("Terrible sleep quality")
                                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                                .opacity(0.4)
                                        }
                                        if sleep.quality == 2.0 {
                                            Text("Bad sleep quality")
                                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                                .opacity(0.4)
                                        }
                                        if sleep.quality == 3.0 {
                                            Text("Good sleep quality")
                                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                                .opacity(0.4)
                                        }
                                        if sleep.quality == 4.0 {
                                            Text("Great sleep quality")
                                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                                .opacity(0.4)
                                        }
                                    }
                                }
                            }
                            .padding()
                        }
                    }
                }
                .padding()
            }
        }
        .background(Color.init(uiColor: .systemGray6))
    }
}

struct SleepScoreListView_Previews: PreviewProvider {
    static var previews: some View {
        SleepScoreListView()
            .environmentObject(HealthKitViewModel())

    }
}
