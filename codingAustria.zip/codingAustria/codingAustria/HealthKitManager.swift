//
//  HealthKitManager.swift
//  codingAustria
//
//  Created by David Pfluegl on 26.07.23.
//

import Foundation
import HealthKit

class HealthKitManager {
    
    func setUpHealthRequest(healthStore: HKHealthStore, readActiveEnergyBurned: @escaping () -> Void) {
        if HKHealthStore.isHealthDataAvailable(), let activeEnergyBurned = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned) {
            healthStore.requestAuthorization(toShare: [activeEnergyBurned], read: [activeEnergyBurned]) { success, error in
                if success {
                    readActiveEnergyBurned()
                } else if error != nil {
                    // handle your error here
                }
            }
        }
    }
    
    func readActiveEnergyCount(forDate date: Date, healthStore: HKHealthStore, completion: @escaping (Double) -> Void) {
        guard let activeEnergyQuantityType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned) else { return }
        
        let startOfDay = Calendar.current.startOfDay(for: date)
        let endOfDay = Calendar.current.date(bySettingHour: 23, minute: 59, second: 59, of: date)!
        
        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: endOfDay, options: .strictStartDate)
        
        let query = HKStatisticsQuery(quantityType: activeEnergyQuantityType, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, result, error in
            
            guard let result = result, let sum = result.sumQuantity() else {
                completion(0.0)
                return
            }
            completion(sum.doubleValue(for: HKUnit.kilocalorie()))
        }
        healthStore.execute(query)
    }
}
