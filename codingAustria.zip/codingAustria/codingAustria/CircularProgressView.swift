//
//  CircularProgressView.swift
//  codingAustria
//
//  Created by David Pfluegl on 29.07.23.
//

import SwiftUI

struct CircularProgressView: View {
    
    let progress: Double

    var body: some View {
        
            ZStack { // 1
                Circle()
                    .stroke(
                        Color.gray.opacity(0.2),
                        lineWidth: 6
                    )
                Circle() // 2
                    .trim(from: 0, to: progress)
                    .stroke(
                        Color.green,
                        style: StrokeStyle(
                            lineWidth: 6,
                            lineCap: .round
                        )
                    )
                    .rotationEffect(.degrees(-90))
                    .animation(.easeOut, value: progress)
            }
        }
    }
